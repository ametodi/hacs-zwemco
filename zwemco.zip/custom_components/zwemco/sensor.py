import requests
from homeassistant.helpers.entity import Entity

class ZwemcoSensor(Entity):
    def __init__(self, name, resource, value_path):
        self._name = name
        self._resource = resource
        self._value_path = value_path
        self._state = None

    @property
    def name(self):
        return self._name

    @property
    def state(self):
        return self._state

    def update(self):
        try:
            r = requests.get(self._resource, timeout=5)
            data = r.json()
            value = data
            for key in self._value_path:
                value = value.get(key)
            self._state = value
        except Exception as e:
            self._state = 'error'